Some resources used for this project:

Stack Overflow:
https://stackoverflow.com/questions/775049/how-to-convert-seconds-to-hours-minutes-and-seconds
https://stackoverflow.com/questions/354883/how-do-you-return-multiple-values-in-python
https://stackoverflow.com/questions/35268817/unique-combinations-of-values-in-selected-columns-in-pandas-data-frame-and-count
https://stackoverflow.com/questions/18327624/find-elements-index-in-pandas-series

Panda Docs:
https://pandas.pydata.org/pandas-docs/stable/generated/pandas.Series.reset_index.html
http://pandas.pydata.org/pandas-docs/stable/groupby.html

Other blog/sites:
https://erikrood.com/Python_References/iterate_rows_pandas.html
